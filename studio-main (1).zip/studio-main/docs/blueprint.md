# **App Name**: LegalTrack CMIS

## Core Features:

- Secure User Authentication: Admin and staff login with role-based access control.
- Dashboard Statistics: Display key metrics like open, closed, and total cases.
- Case Registration: Register new cases with details including title, parties, date, and description.
- Case Management: List, search, and view detailed case information; filter cases by status.
- Status Updates: Update the status of a case.
- Document Uploads: Upload and manage case-related documents (PDF/images).
- Reporting Module: Generate reports for open, closed, and total cases.

## Style Guidelines:

- Primary color: Deep Blue (#004A99) to convey trust and professionalism.
- Background color: Light Blue (#E5F1FF), desaturated and light, creating a calm atmosphere.
- Accent color: Teal (#008080), an analogous color, adds a modern, reliable feel.
- Body text and headline font: 'Inter' sans-serif for a clean, modern look.
- Use minimalist icons to represent case statuses and actions.
- Clean and structured layout to ensure easy navigation.
- Subtle transitions for loading data and status updates.