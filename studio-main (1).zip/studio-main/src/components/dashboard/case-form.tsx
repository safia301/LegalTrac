"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import type { Case, CaseStatus, Mediator } from "@/lib/types";
import { mediators } from "@/lib/data";

const formSchema = z.object({
  title: z.string().min(5, { message: "Title must be at least 5 characters." }),
  parties: z.string().min(2, { message: "Parties involved are required." }),
  dateFiled: z.date({ required_error: "Date filed is required." }),
  description: z.string().min(10, { message: "Description must be at least 10 characters." }),
  mediatorId: z.string().optional(),
  status: z.enum(["Open", "In Progress", "Closed", "On Hold"]),
});

type CaseFormProps = {
  caseData?: Case;
  onSubmit: (data: Case) => Promise<void>;
  onClose: () => void;
};

export function CaseForm({ caseData, onSubmit, onClose }: CaseFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: caseData?.title || "",
      parties: caseData?.parties.join(", ") || "",
      dateFiled: caseData?.dateFiled ? new Date(caseData.dateFiled) : undefined,
      description: caseData?.description || "",
      mediatorId: caseData?.mediator?.id || "",
      status: caseData?.status || "Open",
    },
  });

  const { isSubmitting } = form.formState;

  const handleFormSubmit = async (values: z.infer<typeof formSchema>) => {
    const newCase: Case = {
      id: caseData?.id || `CASE-${Date.now()}`,
      caseNumber: caseData?.caseNumber || `CN-${Date.now()}`,
      title: values.title,
      parties: values.parties.split(",").map(p => p.trim()),
      dateFiled: values.dateFiled.toISOString(),
      description: values.description,
      mediator: mediators.find(m => m.id === values.mediatorId),
      status: values.status as CaseStatus,
      documents: caseData?.documents || [],
      lastUpdated: new Date().toISOString(),
    };
    await onSubmit(newCase);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Case Title</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Commercial Lease Dispute" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="parties"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Parties Involved</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Plaintiff Inc, Defendant LLC" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
            control={form.control}
            name="dateFiled"
            render={({ field }) => (
                <FormItem className="flex flex-col">
                    <FormLabel>Date Filed</FormLabel>
                    <Popover>
                        <PopoverTrigger asChild>
                        <FormControl>
                            <Button
                            variant={"outline"}
                            className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                            )}
                            >
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                        </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                            initialFocus
                        />
                        </PopoverContent>
                    </Popover>
                    <FormMessage />
                </FormItem>
            )}
            />
            <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                    <SelectTrigger>
                        <SelectValue placeholder="Select case status" />
                    </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        <SelectItem value="Open">Open</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="On Hold">On Hold</SelectItem>
                        <SelectItem value="Closed">Closed</SelectItem>
                    </SelectContent>
                </Select>
                <FormMessage />
                </FormItem>
            )}
            />
        </div>

        <FormField
          control={form.control}
          name="mediatorId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Assign Mediator</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a mediator" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {mediators.map(m => (
                    <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Case Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Provide a brief summary of the case..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {caseData ? "Save Changes" : "Create Case"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
