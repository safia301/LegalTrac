"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
  Gavel,
  BookOpen,
  Archive,
  Loader2,
  FolderOpen,
} from "lucide-react";
import { StatCards } from "@/components/dashboard/stats-cards";
import { CaseTable } from "@/components/dashboard/case-table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { CaseForm } from "@/components/dashboard/case-form";
import type { Case, StatCard } from "@/lib/types";
import { initialCases } from "@/lib/data";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function DashboardPage() {
  const [cases, setCases] = useState<Case[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<Case | undefined>(undefined);
  const [caseToDelete, setCaseToDelete] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Simulate fetching data
    setTimeout(() => {
      setCases(initialCases);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleAddNewCase = () => {
    setSelectedCase(undefined);
    setIsFormOpen(true);
  };

  const handleOpenCase = (caseData: Case) => {
    setSelectedCase(caseData);
    setIsFormOpen(true);
  };
  
  const handleDeleteRequest = (caseId: string) => {
    setCaseToDelete(caseId);
    setIsDeleteAlertOpen(true);
  }

  const handleDeleteConfirm = () => {
    if (caseToDelete) {
      setCases(prev => prev.filter(c => c.id !== caseToDelete));
      toast({ title: "Case Deleted", description: "The case has been successfully removed." });
      setCaseToDelete(null);
    }
    setIsDeleteAlertOpen(false);
  }

  const handleFormSubmit = async (data: Case) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    setCases(prev => {
      const existingIndex = prev.findIndex(c => c.id === data.id);
      if (existingIndex > -1) {
        const newCases = [...prev];
        newCases[existingIndex] = data;
        return newCases;
      }
      return [data, ...prev];
    });
    toast({
      title: selectedCase ? "Case Updated" : "Case Created",
      description: `Case "${data.title}" has been successfully saved.`,
    });
    setIsFormOpen(false);
    setSelectedCase(undefined);
  };

  const stats: StatCard[] = useMemo(() => {
    const openCases = cases.filter(c => c.status === "Open").length;
    const closedCases = cases.filter(c => c.status === "Closed").length;
    return [
      { title: "Total Cases", value: cases.length.toString(), icon: FolderOpen, change: "+2 this month" },
      { title: "Open Cases", value: openCases.toString(), icon: BookOpen, change: "-5 from last month" },
      { title: "In Progress", value: cases.filter(c => c.status === 'In Progress').length.toString(), icon: Gavel },
      { title: "Closed Cases", value: closedCases.toString(), icon: Archive, change: "+10 this month" },
    ];
  }, [cases]);
  
  const filteredCases = (status: string) => {
    if (status === 'All') return cases;
    return cases.filter(c => c.status === status);
  }

  return (
    <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      <h1 className="text-2xl font-bold font-headline">Dashboard</h1>
      <StatCards stats={stats} />
      <Tabs defaultValue="All">
        <TabsList>
          <TabsTrigger value="All">All Cases</TabsTrigger>
          <TabsTrigger value="Open">Open</TabsTrigger>
          <TabsTrigger value="In Progress">In Progress</TabsTrigger>
          <TabsTrigger value="Closed">Closed</TabsTrigger>
        </TabsList>
        {['All', 'Open', 'In Progress', 'Closed'].map(status => (
            <TabsContent key={status} value={status}>
                <CaseTable
                    cases={filteredCases(status)}
                    onOpenCase={handleOpenCase}
                    onAddNewCase={handleAddNewCase}
                    onDeleteCase={handleDeleteRequest}
                    isLoading={isLoading}
                />
            </TabsContent>
        ))}
      </Tabs>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[625px]">
          <DialogHeader>
            <DialogTitle>{selectedCase ? "Edit Case" : "Add New Case"}</DialogTitle>
            <DialogDescription>
              {selectedCase ? "Update the details for this case." : "Fill out the form to register a new case."}
            </DialogDescription>
          </DialogHeader>
          <CaseForm
            caseData={selectedCase}
            onSubmit={handleFormSubmit}
            onClose={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the case
              and remove its data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}
