import type { LucideIcon } from "lucide-react";

export type CaseStatus = "Open" | "In Progress" | "Closed" | "On Hold";

export type Case = {
  id: string;
  title: string;
  caseNumber: string;
  parties: string[];
  dateFiled: string;
  description: string;
  mediator?: Mediator;
  status: CaseStatus;
  documents: {
    id: string;
    name: string;
    size: string;
    type: "PDF" | "Image" | "Doc";
    uploadedAt: string;
  }[];
  lastUpdated: string;
};

export type Mediator = {
  id: string;
  name: string;
  avatarUrl: string;
};

export type StatCard = {
  title: string;
  value: string;
  icon: LucideIcon;
  change?: string;
};
