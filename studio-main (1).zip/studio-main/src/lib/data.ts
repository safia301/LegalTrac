import type { Case, Mediator } from "@/lib/types";
import { PlaceHolderImages } from "./placeholder-images";

const getImageUrl = (id: string) => PlaceHolderImages.find(img => img.id === id)?.imageUrl || '';

export const mediators: Mediator[] = [
  { id: "M001", name: "Sammy Agyapong", avatarUrl: getImageUrl('avatar-1') },
  { id: "M002", name: "Sandra Lawson", avatarUrl: getImageUrl('avatar-2') },
  { id: "M003", name: "Kira Blasi", avatarUrl: getImageUrl('avatar-3') },
  { id: "M004", name: "John Ato", avatarUrl: getImageUrl('avatar-4') },
];

export const initialCases: Case[] = [
  {
    id: "CASE-001",
    title: "Commercial Lease Dispute",
    caseNumber: "CLD-2023-018",
    parties: ["Global Imports Inc.", "City Properties LLC"],
    dateFiled: "2025-11-15T00:00:00.000Z",
    description: "Dispute over lease terms and maintenance responsibilities for a commercial property at 123 Main St.",
    mediator: mediators[0],
    status: "In Progress",
    documents: [
      { id: "DOC-001", name: "Lease_Agreement.pdf", size: "1.2 MB", type: "PDF", uploadedAt: "2023-08-15" },
      { id: "DOC-002", name: "Initial_Complaint.pdf", size: "350 KB", type: "PDF", uploadedAt: "2023-08-16" },
      { id: "DOC-003", name: "Property_Damage_Photos.zip", size: "15.8 MB", type: "Image", uploadedAt: "2023-08-20" },
    ],
    lastUpdated: "2024-05-20T00:00:00.000Z",
  },
  {
    id: "CASE-002",
    title: "Employment Contract Negotiation",
    caseNumber: "ECN-2023-051",
    parties: ["Sarah Jenkins", "Tech Solutions Ltd."],
    dateFiled: "2025-12-01T00:00:00.000Z",
    description: "Negotiating terms of an executive employment contract, including salary, stock options, and severance.",
    mediator: mediators[1],
    status: "Open",
    documents: [
       { id: "DOC-004", name: "Draft_Contract.pdf", size: "450 KB", type: "PDF", uploadedAt: "2023-09-01" }
    ],
    lastUpdated: "2024-05-18T00:00:00.000Z",
  },
  {
    id: "CASE-003",
    title: "Intellectual Property Theft",
    caseNumber: "IPT-2022-112",
    parties: ["Innovate Corp.", "Digital Ventures"],
    dateFiled: "2025-11-20T00:00:00.000Z",
    description: "Allegations of intellectual property theft related to a proprietary software algorithm.",
    mediator: mediators[2],
    status: "Closed",
    documents: [
      { id: "DOC-005", name: "Cease_and_Desist.pdf", size: "200 KB", type: "PDF", uploadedAt: "2022-11-20" },
      { id: "DOC-006", name: "Settlement_Agreement.pdf", size: "800 KB", type: "PDF", uploadedAt: "2023-03-10" }
    ],
    lastUpdated: "2023-03-10T00:00:00.000Z",
  },
  {
    id: "CASE-004",
    title: "Family Inheritance Mediation",
    caseNumber: "FIM-2024-003",
    parties: ["The Estate of Robert Johnson"],
    dateFiled: "2025-12-10T00:00:00.000Z",
    description: "Mediation between siblings regarding the distribution of assets from their late father's estate.",
    mediator: mediators[3],
    status: "On Hold",
    documents: [],
    lastUpdated: "2024-04-05T00:00:00.000Z",
  },
  {
    id: "CASE-005",
    title: "Consumer Goods Warranty Claim",
    caseNumber: "CGW-2024-034",
    parties: ["Michael Brown", "Home Appliances Inc."],
    dateFiled: "2025-11-25T00:00:00.000Z",
    description: "Claim regarding a faulty refrigerator under warranty. The company is disputing the cause of the failure.",
    mediator: mediators[0],
    status: "Open",
    documents: [
      { id: "DOC-007", name: "Purchase_Receipt.jpg", size: "2.1 MB", type: "Image", uploadedAt: "2024-04-25" },
      { id: "DOC-008", name: "Warranty_Card.pdf", size: "600 KB", type: "PDF", uploadedAt: "2024-04-25" }
    ],
    lastUpdated: "2024-05-15T00:00:00.000Z",
  },
    {
    id: "CASE-006",
    title: "Real Estate Boundary Dispute",
    caseNumber: "REB-2023-089",
    parties: ["The Miller Family", "The Peterson Estate"],
    dateFiled: "2025-12-05T00:00:00.000Z",
    description: "A dispute concerning the property line between two adjacent residential lots.",
    mediator: mediators[1],
    status: "In Progress",
    documents: [],
    lastUpdated: "2024-05-01T00:00:00.000Z",
  },
];
